load("lib/integrationservices/javascript/xmio.js");
// ----------------------------------------------------------------------------------------------------
// Configuration settings for an xMatters Relevance Engine Integration
// ----------------------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------------------
// The url that will be used to inject events into xMatters.
// ----------------------------------------------------------------------------------------------------
WEB_SERVICE_URL = "";

//----------------------------------------------------------------------------------------------------
//The username and password used to authenticate the request to xMatters.
//The PASSWORD value is a path to a file where the
//user's password should be encrypted using the iapassword.sh utility.
//Please see the integration agent documentation for instructions.
//----------------------------------------------------------------------------------------------------
INITIATOR="zabbix"
PASSWORD="conf/.wspasswd";


ZABBIX_API_URL = "http://localhost/zabbix/api_jsonrpc.php"
ZABBIX_USER = "xMatters";
ZABBIX_PASSWORD_LOC = "integrationservices/zabbix/.zabbixpasswd";
// decryptFile returns a Java object, which causes issues when working with JSON. Adding the
// empty string converts it to a Javascript object.
ZABBIX_PASSWORD = "" + XMIO.decryptFile(ZABBIX_PASSWORD_LOC).toString();

// ----------------------------------------------------------------------------------------------------
// Callbacks requested for this integration service.
// ----------------------------------------------------------------------------------------------------
CALLBACKS = [];

// ----------------------------------------------------------------------------------------------------
// Filter to use in <IAHOME>/conf/deduplicator-filter.xml
// ----------------------------------------------------------------------------------------------------
DEDUPLICATION_FILTER_NAME = "default";
